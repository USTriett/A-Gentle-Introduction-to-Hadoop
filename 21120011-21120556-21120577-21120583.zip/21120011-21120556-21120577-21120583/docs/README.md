# Course: Introduction to Big Data HCMUS
# Lab1
## Members

- 21120011 - Võ Hoàng Hưng
- 21120556 - Trần Kỳ Thanh
- 21120577 - Huỳnh Công Triết
- 21120583 - Hoàng Thế Trung
